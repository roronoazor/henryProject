import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        try {

            Manager manager = new Manager();
            manager.generateReport();
            System.out.println("Report has been written to the src/reports.txt file");

            Scanner command = new Scanner(System.in);
            System.out.println("Enter competitor number to view details or exit to close: ");

            boolean running = true;
            while(running){

                String competitorNumber = command.nextLine();
                switch (competitorNumber) {
                    case "exit" -> {
                        System.out.println("Application Closed");
                        running = false;
                    }
                    default -> manager.findCompetitor(competitorNumber);
                }
            }
            command.close();

        } catch (FileNotFoundException e) {
            // if the file is not found, print out a console error
            System.out.println("Cannot find competitors file, please ensure the file to be read is in the src folder");
            throw new RuntimeException(e);
        }
    }
}